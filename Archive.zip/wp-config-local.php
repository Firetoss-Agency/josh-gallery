<?php

// Local server settings
define('WP_HOME', 'http://josh-gallery.test');
define('WP_SITEURL', WP_HOME);

// ** MySQL settings ** //
/** The name of the database for WordPress */
define('DB_NAME', 'db_josh-gallery');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', '127.0.0.1');

/** Define the environment, for Roots/Sage */
define('WP_ENV', 'development');
